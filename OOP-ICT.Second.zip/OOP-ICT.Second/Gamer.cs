namespace OOP_ICT.Second;

public class Gamer
{
    
}